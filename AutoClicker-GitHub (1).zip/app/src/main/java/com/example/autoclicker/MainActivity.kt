package com.example.autoclicker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.WHITE)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        root.addView(TextView(this).apply {
            text = "أوتو كلكر"
            textSize = 28f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        })

        root.addView(TextView(this).apply {
            text = "طريقة الاستخدام:\n\n" +
                "1) اضغط الزر بالأسفل وفعّل خدمة «أوتو كلكر» من إعدادات الوصول.\n\n" +
                "2) ستظهر لوحة عائمة فوق أي تطبيق.\n\n" +
                "3) زر «+ ضغطة» يضيف نقطة ضغط، وزر «+ سحب» يضيف نقطة بداية ونهاية. " +
                "حرّك الدوائر إلى الأماكن المطلوبة.\n\n" +
                "4) زر «⏱» يغيّر الفاصل بين الحركات.\n\n" +
                "5) اضغط «▶» للتشغيل و«■» للإيقاف.\n\n" +
                "الدوائر تُرتّب بالأرقام وتُنفَّذ بالترتيب وتتكرر."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, pad, 0, pad)
        })

        root.addView(Button(this).apply {
            text = "فتح إعدادات الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        setContentView(root)
    }
}
