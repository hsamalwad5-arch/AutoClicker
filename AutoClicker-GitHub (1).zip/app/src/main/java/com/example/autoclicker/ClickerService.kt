package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class ClickerService : AccessibilityService() {

    private class Marker(val view: TextView, val params: WindowManager.LayoutParams)

    // خطوة واحدة: ضغطة (a فقط) أو سحب (من a إلى b)
    private class Step(val a: Marker, val b: Marker?)

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val steps = mutableListOf<Step>()

    private var panel: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var playButton: Button? = null
    private var bubble: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private var running = false
    private var index = 0
    private val intervals = longArrayOf(100, 200, 300, 500, 800, 1000, 2000)
    private var intervalIdx = 3
    private val swipeDurationMs = 350L

    private val markerSize by lazy { (52 * resources.displayMetrics.density).toInt() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopPlaying()
    }

    override fun onDestroy() {
        stopPlaying()
        clearAll()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        super.onDestroy()
    }

    // ---------- اللوحة العائمة ----------

    private fun showPanel() {
        val d = resources.displayMetrics.density
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6202124"))
                cornerRadius = 28 * d
            }
        }

        fun btn(label: String, onClick: (Button) -> Unit) = Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            setPadding((10 * d).toInt(), 0, (10 * d).toInt(), 0)
            setOnClickListener { onClick(this) }
        }

        // مقبض السحب
        val handle = TextView(this).apply {
            text = "⠿"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding((8 * d).toInt(), 0, (8 * d).toInt(), 0)
            gravity = Gravity.CENTER
        }
        bar.addView(handle)

        bar.addView(btn("+ ضغطة") { addTap() })
        bar.addView(btn("+ سحب") { addSwipe() })
        playButton = btn("▶") { togglePlay() }
        bar.addView(playButton)
        bar.addView(btn("⏱ ${intervals[intervalIdx]}") { b ->
            intervalIdx = (intervalIdx + 1) % intervals.size
            b.text = "⏱ ${intervals[intervalIdx]}"
        })
        bar.addView(btn("🗑") { stopPlaying(); clearAll() })
        bar.addView(btn("−") { collapse() })
        bar.addView(btn("✕") {
            stopPlaying()
            clearAll()
            disableSelf()
        })

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (8 * d).toInt()
            y = (80 * d).toInt()
        }

        makeDraggable(handle, p, bar)
        panel = bar
        panelParams = p
        wm.addView(bar, p)
        createBubble(p)
    }

    // ---------- الزر الدائري (القائمة المصغّرة) ----------

    private fun createBubble(from: WindowManager.LayoutParams) {
        val tv = TextView(this).apply {
            text = "🎮"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E6202124"))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
            visibility = View.GONE
        }
        val bp = WindowManager.LayoutParams(
            markerSize, markerSize,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = from.x
            y = from.y
        }
        makeDraggable(tv, bp, tv) { onBubbleTap() }
        bubble = tv
        bubbleParams = bp
        wm.addView(tv, bp)
    }

    private fun collapse() {
        val b = bubble ?: return
        val bp = bubbleParams ?: return
        val pp = panelParams ?: return
        bp.x = pp.x
        bp.y = pp.y
        runCatching { wm.updateViewLayout(b, bp) }
        panel?.visibility = View.GONE
        b.visibility = View.VISIBLE
    }

    private fun expand() {
        val b = bubble ?: return
        val bp = bubbleParams ?: return
        val pp = panelParams ?: return
        val pnl = panel ?: return
        pp.x = bp.x
        pp.y = bp.y
        runCatching { wm.updateViewLayout(pnl, pp) }
        b.visibility = View.GONE
        pnl.visibility = View.VISIBLE
    }

    // أثناء التشغيل: ضغطة على الزر توقف. وإلا تفتح القائمة.
    private fun onBubbleTap() {
        if (running) stopPlaying() else expand()
    }

    // ---------- العلامات ----------

    private fun newMarker(label: String, color: String, x: Int, y: Int): Marker {
        val tv = TextView(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(color))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
        }
        val p = WindowManager.LayoutParams(
            markerSize, markerSize,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
        makeDraggable(tv, p, tv)
        wm.addView(tv, p)
        return Marker(tv, p)
    }

    private fun addTap() {
        if (running) return
        val n = steps.size + 1
        val m = newMarker("$n", "#E53935", 300 + n * 20, 500 + n * 20)
        steps.add(Step(m, null))
    }

    private fun addSwipe() {
        if (running) return
        val n = steps.size + 1
        val start = newMarker("$n", "#43A047", 300 + n * 20, 500 + n * 20)
        val end = newMarker("$n›", "#1E88E5", 300 + n * 20, 900 + n * 20)
        steps.add(Step(start, end))
    }

    private fun clearAll() {
        steps.forEach { s ->
            runCatching { wm.removeView(s.a.view) }
            s.b?.let { runCatching { wm.removeView(it.view) } }
        }
        steps.clear()
    }

    private fun makeDraggable(
        touchTarget: View,
        params: WindowManager.LayoutParams,
        window: View,
        onTap: (() -> Unit)? = null
    ) {
        var startX = 0f
        var startY = 0f
        var origX = 0
        var origY = 0
        var moved = false
        val slop = 12 * resources.displayMetrics.density
        touchTarget.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.rawX; startY = e.rawY
                    origX = params.x; origY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startX
                    val dy = e.rawY - startY
                    if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true
                    params.x = origX + dx.toInt()
                    params.y = origY + dy.toInt()
                    runCatching { wm.updateViewLayout(window, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                    true
                }
                else -> true
            }
        }
    }

    // العلامات تصير شفافة للمس أثناء التشغيل حتى تمر الضغطات للتطبيق اللي تحتها
    private fun setMarkersTouchable(touchable: Boolean) {
        val all = steps.flatMap { listOfNotNull(it.a, it.b) }
        all.forEach { m ->
            m.params.flags = if (touchable) {
                m.params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            } else {
                m.params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            runCatching { wm.updateViewLayout(m.view, m.params) }
            m.view.alpha = if (touchable) 1f else 0.55f
        }
    }

    // ---------- التشغيل ----------

    private fun togglePlay() {
        if (running) stopPlaying() else startPlaying()
    }

    private fun startPlaying() {
        if (steps.isEmpty()) {
            Toast.makeText(this, "أضف نقطة ضغط أو سحب أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        running = true
        index = 0
        playButton?.text = "■"
        bubble?.text = "■"
        setMarkersTouchable(false)
        handler.postDelayed({ runStep() }, 400)
    }

    private fun stopPlaying() {
        running = false
        handler.removeCallbacksAndMessages(null)
        playButton?.text = "▶"
        bubble?.text = "🎮"
        setMarkersTouchable(true)
    }

    private fun center(m: Marker): Pair<Float, Float> {
        val loc = IntArray(2)
        m.view.getLocationOnScreen(loc)
        return Pair(loc[0] + m.view.width / 2f, loc[1] + m.view.height / 2f)
    }

    private fun runStep() {
        if (!running || steps.isEmpty()) return
        val step = steps[index % steps.size]
        index++

        val (x1, y1) = center(step.a)
        val path = Path().apply { moveTo(x1, y1) }
        val duration: Long
        if (step.b != null) {
            val (x2, y2) = center(step.b)
            path.lineTo(x2, y2)
            duration = swipeDurationMs
        } else {
            duration = 50L
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, duration))
            .build()

        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) = scheduleNext()
            override fun onCancelled(g: GestureDescription?) = scheduleNext()
        }, null)
        if (!ok) scheduleNext()
    }

    private fun scheduleNext() {
        if (running) handler.postDelayed({ runStep() }, intervals[intervalIdx])
    }
}
